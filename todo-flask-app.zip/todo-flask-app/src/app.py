import sqlite3
from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)

# Database initialization function
def init_db():
    with sqlite3.connect('instance/todo.db') as conn:
        cursor = conn.cursor()
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS tasks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                task TEXT NOT NULL,
                completed BOOLEAN NOT NULL CHECK (completed IN (0, 1))
            )
        ''')
        conn.commit()

# Function to fetch all tasks from the database
def get_tasks():
    with sqlite3.connect('instance/todo.db') as conn:
        cursor = conn.cursor()
        cursor.execute('SELECT id, task, completed FROM tasks')
        tasks = cursor.fetchall()
    return tasks

# Function to add a task to the database
def add_task(task):
    with sqlite3.connect('instance/todo.db') as conn:
        cursor = conn.cursor()
        cursor.execute('INSERT INTO tasks (task, completed) VALUES (?, ?)', (task, False))
        conn.commit()

# Function to delete a task from the database
def delete_task(task_id):
    with sqlite3.connect('instance/todo.db') as conn:
        cursor = conn.cursor()
        cursor.execute('DELETE FROM tasks WHERE id = ?', (task_id,))
        conn.commit()

# Function to mark a task as completed
def toggle_task_status(task_id):
    with sqlite3.connect('instance/todo.db') as conn:
        cursor = conn.cursor()
        cursor.execute('UPDATE tasks SET completed = NOT completed WHERE id = ?', (task_id,))
        conn.commit()

# Initialize the database (only needs to be run once)
init_db()

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        new_task = request.form['task']
        if new_task:
            add_task(new_task)  # Add new task to the database
        return redirect(url_for('index'))  # Redirect to avoid re-submitting the form

    tasks = get_tasks()  # Fetch tasks from the database
    return render_template('index.html', tasks=tasks)

@app.route('/delete/<int:task_id>', methods=['GET'])
def delete(task_id):
    delete_task(task_id)  # Delete the task from the database
    return redirect(url_for('index'))  # Redirect to the main page

@app.route('/toggle/<int:task_id>', methods=['GET'])
def toggle(task_id):
    toggle_task_status(task_id)  # Toggle task completion status
    return redirect(url_for('index'))  # Redirect to the main page

if __name__ == '__main__':
    app.run(debug=True)
